from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.uix.image import Image
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.metrics import dp, sp
from kivy.properties import StringProperty, NumericProperty, ListProperty
import random
import os
import re
import json


class BackgroundImage(Image):
    """背景图片组件"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.allow_stretch = True
        self.keep_ratio = True
        self.source = '200.jpg' if os.path.exists('200.jpg') else ''
        self.color = [1, 1, 1, 0.9]


class ColoredBoxLayout(BoxLayout):
    """带背景色和圆角的BoxLayout"""
    bg_color = ListProperty([0.1, 0.1, 0.15, 0.85])
    radius = NumericProperty(dp(15))

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bind(pos=self.update_rect, size=self.update_rect)

    def update_rect(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*self.bg_color)
            RoundedRectangle(pos=self.pos, size=self.size, radius=[self.radius])


class RoundedButton(Button):
    """圆角按钮"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.font_size = sp(18)
        self.size_hint_y = None
        self.height = dp(50)

        with self.canvas.before:
            Color(*self.background_color)
            self.rect = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[dp(10)]
            )
        self.bind(pos=self.update_rect, size=self.update_rect)

        self.background_normal = ''
        self.background_down = ''

    def update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size


class ToggleOption(ToggleButton):
    """自定义选项按钮"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_color = [0.25, 0.25, 0.3, 0.8]
        self.font_size = sp(16)
        self.size_hint_y = None
        self.height = dp(60)
        self.halign = 'left'
        self.valign = 'middle'

        with self.canvas.before:
            Color(*self.background_color)
            self.rect = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[dp(8)]
            )
        self.bind(
            pos=self.update_rect,
            size=self.update_rect,
            state=self.on_state_change
        )

    def update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size

    def on_state_change(self, instance, value):
        if value == 'down':
            self.background_color = [0.2, 0.6, 0.86, 0.9]
        else:
            self.background_color = [0.25, 0.25, 0.3, 0.8]


class BronyaQuestionScreen(BoxLayout):
    """布洛妮娅问题屏幕"""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.orientation = 'vertical'
        self.spacing = dp(20)
        self.padding = [dp(20), dp(40), dp(20), dp(40)]

        # 添加动态渐变背景
        with self.canvas.before:
            Color(0.15, 0.1, 0.2, 1)
            self.bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self.update_bg, size=self.update_bg)

        # 主容器
        container = ColoredBoxLayout(
            orientation='vertical',
            size_hint=(0.95, 0.9),
            pos_hint={'center_x': 0.5, 'center_y': 0.5},
            spacing=dp(25),
            padding=[dp(30), dp(30), dp(30), dp(30)],
            bg_color=[0.2, 0.15, 0.25, 0.9]
        )

        # 可爱标题
        title_label = Label(
            text='[color=ff66cc]✧ 重要问题 ✧[/color]',
            font_size=sp(32),
            bold=True,
            markup=True,
            size_hint=(1, 0.2)
        )
        container.add_widget(title_label)

        # 问题文本
        question_label = Label(
            text='[color=ffffff]你是否愿意永远喜欢\n[color=ff66cc]布洛妮娅[/color]？[/color]',
            font_size=sp(28),
            markup=True,
            halign='center',
            size_hint=(1, 0.3)
        )
        container.add_widget(question_label)

        # 可爱装饰
        decoration_label = Label(
            text='♥ ♡ ♥ ♡ ♥',
            font_size=sp(24),
            color=[1, 0.8, 0.9, 1],
            size_hint=(1, 0.1)
        )
        container.add_widget(decoration_label)

        # 2x2选项网格
        options_grid = GridLayout(
            cols=2,
            spacing=dp(15),
            size_hint=(1, 0.4)
        )

        # 创建四个大号选项按钮
        option_colors = [
            [1, 0.6, 0.8, 1],
            [1, 0.4, 0.7, 1],
            [1, 0.2, 0.6, 1],
            [0.8, 0.2, 0.5, 1]
        ]

        option_texts = [
            "喜欢",
            "非常喜欢",
            "超级喜欢",
            "我是布洛妮娅的狗"
        ]

        for i in range(4):
            btn = Button(
                text=option_texts[i],
                font_size=sp(24),
                bold=True,
                background_color=option_colors[i],
                background_normal='',
                color=[1, 1, 1, 1]
            )
            btn.bind(on_press=lambda btn, idx=i: self.select_option(idx))
            options_grid.add_widget(btn)

        container.add_widget(options_grid)

        # 提示文字
        hint_label = Label(
            text='[color=aaaaaa]选择后将在主菜单显示你的爱意程度[/color]',
            font_size=sp(16),
            markup=True,
            italic=True,
            size_hint=(1, 0.1)
        )
        container.add_widget(hint_label)

        self.add_widget(container)

    def update_bg(self, *args):
        """更新背景位置和大小"""
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size

    def select_option(self, option_index):
        """选择选项"""
        # 保存选择到应用设置
        self.app.bronya_love_level = option_index + 1
        self.app.has_answered_bronya = True

        # 显示确认动画效果
        confirm_texts = [
            "选择成功！布洛妮娅感受到了你的心意 ♥",
            "太棒了！布洛妮娅会记住你的爱意 ♥♥",
            "哇！超级喜欢！布洛妮娅太开心了！ ♥♥♥",
            "誓言收到！永远追随布洛妮娅大人！ 🐾♥"
        ]

        # 显示确认弹窗
        self.show_confirmation(confirm_texts[option_index])

    def show_confirmation(self, message):
        """显示确认弹窗"""
        content = BoxLayout(orientation='vertical', spacing=dp(15))

        # 爱心图标
        heart_label = Label(
            text='♥' * min(3, self.app.bronya_love_level) + '♡' * max(0, 3 - self.app.bronya_love_level),
            font_size=sp(36),
            color=[1, 0.6, 0.8, 1]
        )
        content.add_widget(heart_label)

        # 确认消息
        msg_label = Label(
            text=message,
            font_size=sp(20),
            markup=True,
            halign='center'
        )
        content.add_widget(msg_label)

        popup = Popup(
            title='誓约达成',
            title_size=sp(24),
            title_color=[1, 1, 1, 1],
            content=content,
            size_hint=(0.8, 0.5),
            separator_color=[1, 0.6, 0.8, 1],
            background_color=[0.2, 0.15, 0.25, 0.95],
            separator_height=0
        )

        # 确认按钮
        confirm_btn = Button(
            text='进入主菜单',
            font_size=sp(18),
            background_color=[1, 0.6, 0.8, 1],
            color=[1, 1, 1, 1],
            size_hint=(1, 0.3)
        )
        confirm_btn.bind(on_press=lambda x: (popup.dismiss(), self.app.show_main_menu()))
        content.add_widget(confirm_btn)

        popup.open()


class MainMenuScreen(BoxLayout):
    """主菜单屏幕"""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.orientation = 'vertical'
        self.spacing = dp(20)
        self.padding = [dp(20), dp(40), dp(20), dp(40)]

        # 背景
        if os.path.exists('200.jpg'):
            bg = Image(
                source='200.jpg',
                allow_stretch=True,
                keep_ratio=True
            )
            self.add_widget(bg)

        # 主内容容器
        self.container = ColoredBoxLayout(
            orientation='vertical',
            size_hint=(0.9, 0.8),
            pos_hint={'center_x': 0.5, 'center_y': 0.5},
            spacing=dp(25),
            padding=[dp(25), dp(25), dp(25), dp(25)]
        )
        self.update_title()

        # 按钮容器
        button_container = BoxLayout(
            orientation='vertical',
            spacing=dp(15),
            size_hint=(1, 0.6)
        )

        # 选择题按钮
        choice_btn = RoundedButton(
            text='选择题练习',
            font_size=sp(22),
            background_color=[0.2, 0.6, 0.86, 1],
            size_hint=(1, None),
            height=dp(60)
        )
        choice_btn.bind(on_press=lambda x: self.app.show_choice_screen())
        button_container.add_widget(choice_btn)

        # 判断题按钮
        judge_btn = RoundedButton(
            text='判断题练习',
            font_size=sp(22),
            background_color=[0.18, 0.8, 0.44, 1],
            size_hint=(1, None),
            height=dp(60)
        )
        judge_btn.bind(on_press=lambda x: self.app.show_judge_screen())  # 修复：on_press 而不是 on_prompt
        button_container.add_widget(judge_btn)

        # 退出按钮
        exit_btn = RoundedButton(
            text='退出系统',
            font_size=sp(22),
            background_color=[0.91, 0.3, 0.24, 1],
            size_hint=(1, None),
            height=dp(60)
        )
        exit_btn.bind(on_press=lambda x: self.app.stop())
        button_container.add_widget(exit_btn)

        self.container.add_widget(button_container)

        # 版本信息
        version_label = Label(
            text='版本 1.0 | 军事知识学习系统',
            font_size=sp(14),
            color=[0.7, 0.7, 0.7, 1],
            size_hint=(1, 0.1)
        )
        self.container.add_widget(version_label)

        self.add_widget(self.container)

    def update_title(self):
        """更新标题，根据布洛妮娅爱心等级"""
        # 清除现有标题（如果存在）
        for widget in self.container.children[:]:
            if isinstance(widget, Label) and ('WAR GUIDE TALK' in widget.text or '♥' in widget.text):
                self.container.remove_widget(widget)

        # 根据爱心等级创建标题
        love_level = getattr(self.app, 'bronya_love_level', 0)

        if love_level == 0:
            title_text = 'WAR GUIDE TALK'
        elif love_level == 1:
            title_text = 'WAR GUIDE TALK ♥'
        elif love_level == 2:
            title_text = 'WAR GUIDE TALK ♥♥'
        elif love_level == 3:
            title_text = 'WAR GUIDE TALK ♥♥♥'
        elif love_level == 4:
            title_text = '♥♥♥♥♥♥'
        else:
            title_text = 'WAR GUIDE TALK'

        # 创建标题标签
        title_label = Label(
            text=title_text,
            font_size=sp(32),
            bold=True,
            color=[1, 1, 1, 1],
            size_hint=(1, 0.3)
        )

        # 如果是最高等级，添加特殊颜色
        if love_level == 4:
            title_label.color = [1, 0.6, 0.8, 1]
            title_label.font_size = sp(36)

        # 添加到容器开头
        self.container.add_widget(title_label)


class QuizScreen(BoxLayout):
    """答题屏幕基类"""

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.orientation = 'vertical'
        self.spacing = dp(10)
        self.padding = [dp(10), dp(10), dp(10), dp(10)]

        self.current_index = 0
        self.score = 0
        self.wrong_questions = []
        self.current_questions = []
        self.selected_options = []

        self.create_interface()

    def create_interface(self):
        """创建界面"""
        if os.path.exists('200.jpg'):
            bg = Image(
                source='200.jpg',
                allow_stretch=True,
                keep_ratio=True
            )
            self.add_widget(bg)

        self.main_container = ColoredBoxLayout(
            orientation='vertical',
            size_hint=(0.95, 0.95),
            pos_hint={'center_x': 0.5, 'center_y': 0.5},
            spacing=dp(15),
            padding=[dp(20), dp(20), dp(20), dp(20)]
        )

        self.create_top_bar()
        self.create_question_area()
        self.create_bottom_bar()

        self.add_widget(self.main_container)

    def create_top_bar(self):
        """创建顶部信息栏"""
        top_bar = BoxLayout(
            orientation='horizontal',
            size_hint=(1, 0.12),
            spacing=dp(10)
        )

        back_btn = RoundedButton(
            text='返回',
            size_hint=(0.2, 1),
            background_color=[0.8, 0.2, 0.2, 0.9],
            font_size=sp(16)
        )
        back_btn.bind(on_press=lambda x: self.app.show_main_menu())
        top_bar.add_widget(back_btn)

        self.progress_label = Label(
            text='题目: 0/0',
            font_size=sp(18),
            bold=True,
            color=[1, 1, 1, 1]
        )
        top_bar.add_widget(self.progress_label)

        self.score_label = Label(
            text='得分: 0',
            font_size=sp(18),
            bold=True,
            color=[1, 1, 1, 1]
        )
        top_bar.add_widget(self.score_label)

        self.main_container.add_widget(top_bar)

    def create_question_area(self):
        """创建题目显示区域"""
        question_scroll = ScrollView(
            size_hint=(1, 0.4),
            do_scroll_x=False,
            bar_width=dp(8)
        )

        self.question_label = Label(
            text='',
            font_size=sp(20),
            size_hint_y=None,
            color=[1, 1, 1, 1],
            text_size=(Window.width * 0.85, None),
            halign='left',
            valign='top',
            markup=True
        )
        self.question_label.bind(texture_size=self.question_label.setter('size'))
        question_scroll.add_widget(self.question_label)
        self.main_container.add_widget(question_scroll)

        self.options_container = GridLayout(
            cols=1,
            spacing=dp(10),
            size_hint=(1, 0.4),
            size_hint_y=None
        )
        self.options_container.bind(minimum_height=self.options_container.setter('height'))

        options_scroll = ScrollView(
            size_hint=(1, 0.4),
            do_scroll_x=False,
            bar_width=dp(8)
        )
        options_scroll.add_widget(self.options_container)
        self.main_container.add_widget(options_scroll)

    def create_bottom_bar(self):
        """创建底部按钮区域"""
        bottom_bar = BoxLayout(
            orientation='horizontal',
            size_hint=(1, 0.15),
            spacing=dp(10)
        )

        self.prev_btn = RoundedButton(
            text='上一题',
            font_size=sp(16),
            background_color=[0.95, 0.77, 0.06, 1],
            size_hint=(0.25, 1)
        )
        self.prev_btn.bind(on_press=self.prev_question)
        bottom_bar.add_widget(self.prev_btn)

        self.submit_btn = RoundedButton(
            text='提交答案',
            font_size=sp(16),
            background_color=[0.2, 0.6, 0.86, 1],
            size_hint=(0.35, 1)
        )
        self.submit_btn.bind(on_press=self.submit_answer)
        bottom_bar.add_widget(self.submit_btn)

        self.next_btn = RoundedButton(
            text='下一题',
            font_size=sp(16),
            background_color=[0.18, 0.8, 0.44, 1],
            size_hint=(0.25, 1)
        )
        self.next_btn.bind(on_press=self.next_question)
        bottom_bar.add_widget(self.next_btn)

        self.main_container.add_widget(bottom_bar)

    def start_quiz(self, questions):
        """开始答题"""
        self.current_questions = questions.copy()
        random.shuffle(self.current_questions)
        self.current_index = 0
        self.score = 0
        self.wrong_questions = []
        self.selected_options = [''] * len(self.current_questions)

        self.update_button_states()
        self.load_question()

    def load_question(self):
        """加载题目"""
        if self.current_index < len(self.current_questions):
            question_data = self.current_questions[self.current_index]

            question_num = self.current_index + 1
            total_questions = len(self.current_questions)
            question_text = f'[color=ffffff]第{question_num}题（共{total_questions}题）:[/color]\n\n{question_data["question"]}'
            self.question_label.text = question_text

            self.progress_label.text = f'进度: {question_num}/{total_questions}'
            self.score_label.text = f'得分: {self.score}'

            self.options_container.clear_widgets()
            self.update_button_states()

    def select_option(self, button, option_idx):
        """选择选项"""
        question_data = self.current_questions[self.current_index]

        if question_data["is_multiple"]:
            if button.state == 'down':
                if str(option_idx + 1) not in self.selected_options[self.current_index]:
                    self.selected_options[self.current_index] += str(option_idx + 1)
            else:
                current = self.selected_options[self.current_index]
                self.selected_options[self.current_index] = current.replace(str(option_idx + 1), '')
        else:
            self.selected_options[self.current_index] = str(option_idx + 1)

    def submit_answer(self, instance):
        """提交答案"""
        if not self.selected_options[self.current_index]:
            self.show_message("提示", "请先选择答案！")
            return

        question_data = self.current_questions[self.current_index]
        correct_answer = question_data["answer"]
        user_answer = self.selected_options[self.current_index]

        if question_data["is_multiple"]:
            user_answer = ''.join(sorted(user_answer))
            correct_answer = ''.join(sorted(correct_answer))

        if user_answer == correct_answer:
            self.score += 1
            self.show_message("正确", "✓ 回答正确！", is_correct=True)
        else:
            self.wrong_questions.append({
                "question": question_data["question"],
                "user_answer": user_answer,
                "correct_answer": correct_answer
            })
            self.show_message("错误", f"✗ 回答错误\n\n正确答案: {correct_answer}\n你的答案: {user_answer}",
                              is_correct=False)

        self.score_label.text = f'得分: {self.score}'

    def prev_question(self, instance):
        """上一题"""
        if self.current_index > 0:
            self.current_index -= 1
            self.load_question()

    def next_question(self, instance):
        """下一题"""
        if self.current_index < len(self.current_questions) - 1:
            self.current_index += 1
            self.load_question()
        else:
            self.show_results()

    def update_button_states(self):
        """更新按钮状态"""
        self.prev_btn.disabled = self.current_index == 0
        self.prev_btn.background_color = [0.95, 0.77, 0.06, 0.5] if self.prev_btn.disabled else [0.95, 0.77, 0.06, 1]

        if self.current_index == len(self.current_questions) - 1:
            self.next_btn.text = "查看结果"
        else:
            self.next_btn.text = "下一题"

    def show_message(self, title, message, is_correct=True):
        """显示消息弹窗"""
        color = [0.18, 0.8, 0.44, 1] if is_correct else [0.91, 0.3, 0.24, 1]

        content = BoxLayout(orientation='vertical', spacing=dp(10))
        content.add_widget(Label(
            text=message,
            font_size=sp(18),
            color=[1, 1, 1, 1],
            text_size=(Window.width * 0.6, None),
            halign='center'
        ))

        popup = Popup(
            title=title,
            title_color=[1, 1, 1, 1],
            title_size=sp(20),
            content=content,
            size_hint=(0.8, 0.5),
            separator_color=color,
            background_color=[0.1, 0.1, 0.15, 0.95]
        )

        close_btn = RoundedButton(
            text='确定',
            size_hint=(1, None),
            height=dp(40),
            background_color=color
        )
        close_btn.bind(on_press=popup.dismiss)
        content.add_widget(close_btn)

        popup.open()

    def show_results(self):
        """显示结果"""
        total = len(self.current_questions)
        accuracy = (self.score / total * 100) if total > 0 else 0

        content = BoxLayout(orientation='vertical', spacing=dp(15))

        content.add_widget(Label(
            text="答题完成！",
            font_size=sp(24),
            bold=True,
            color=[0.2, 0.6, 0.86, 1]
        ))

        stats_text = f"""
总分: [color=ffffff]{self.score}/{total}[/color]
正确率: [color=ffffff]{accuracy:.1f}%[/color]
用时: [color=ffffff]--[/color]
"""
        if self.wrong_questions:
            stats_text += f"\n错题数: [color=ff4444]{len(self.wrong_questions)}[/color]"

        stats_label = Label(
            text=stats_text,
            font_size=sp(18),
            markup=True,
            halign='center'
        )
        content.add_widget(stats_label)

        btn_container = BoxLayout(
            orientation='horizontal',
            size_hint=(1, 0.3),
            spacing=dp(10)
        )

        if self.wrong_questions:
            review_btn = RoundedButton(
                text='查看错题',
                background_color=[0.91, 0.3, 0.24, 1],
                size_hint=(0.5, 1)
            )
            review_btn.bind(on_press=self.show_wrong_questions)
            btn_container.add_widget(review_btn)

        home_btn = RoundedButton(
            text='返回主菜单',
            background_color=[0.2, 0.6, 0.86, 1],
            size_hint=(0.5, 1)
        )
        home_btn.bind(on_press=lambda x: (self.dismiss_popup(), self.app.show_main_menu()))
        btn_container.add_widget(home_btn)

        content.add_widget(btn_container)

        self.result_popup = Popup(
            title='答题结果',
            title_size=sp(22),
            content=content,
            size_hint=(0.85, 0.7),
            background_color=[0.1, 0.1, 0.15, 0.95]
        )
        self.result_popup.open()

    def show_wrong_questions(self, instance):
        """显示错题"""
        self.dismiss_popup()
        self.show_message("错题", f"共有 {len(self.wrong_questions)} 道错题")

    def dismiss_popup(self):
        """关闭弹窗"""
        if hasattr(self, 'result_popup'):
            self.result_popup.dismiss()


class ChoiceScreen(QuizScreen):
    """选择题答题屏幕"""

    def __init__(self, app, **kwargs):
        super().__init__(app, **kwargs)

    def load_question(self):
        """加载选择题"""
        super().load_question()

        if self.current_index < len(self.current_questions):
            question_data = self.current_questions[self.current_index]
            options = question_data["options"]

            for i, option_text in enumerate(options):
                btn = ToggleOption(
                    text=f'{chr(65 + i)}. {option_text}',
                    group='choice' + str(self.current_index) if not question_data["is_multiple"] else None
                )
                btn.bind(on_press=lambda btn, idx=i: self.select_option(btn, idx))

                if str(i + 1) in self.selected_options[self.current_index]:
                    btn.state = 'down'

                self.options_container.add_widget(btn)


class JudgeScreen(QuizScreen):
    """判断题答题屏幕"""

    def __init__(self, app, **kwargs):
        super().__init__(app, **kwargs)

    def load_question(self):
        """加载判断题"""
        super().load_question()

        if self.current_index < len(self.current_questions):
            true_btn = ToggleOption(
                text='✓ 正确',
                group='judge' + str(self.current_index)
            )
            true_btn.bind(on_press=lambda x: self.select_judge('1'))

            false_btn = ToggleOption(
                text='✗ 错误',
                group='judge' + str(self.current_index)
            )
            false_btn.bind(on_press=lambda x: self.select_judge('0'))

            if self.selected_options[self.current_index] == '1':
                true_btn.state = 'down'
            elif self.selected_options[self.current_index] == '0':
                false_btn.state = 'down'

            self.options_container.add_widget(true_btn)
            self.options_container.add_widget(false_btn)

    def select_judge(self, answer):
        """选择判断题答案"""
        self.selected_options[self.current_index] = answer


class WarGuideTalkApp(App):
    """主应用"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = 'WAR GUIDE TALK'
        self.icon = '100.PNG' if os.path.exists('100.PNG') else None

        # 布洛妮娅爱心相关
        self.bronya_love_level = 0
        self.has_answered_bronya = False

        # 题库数据
        self.choice_questions = []
        self.judge_questions = []

        # 加载题库
        self.load_questions()

        # 界面组件
        self.container = BoxLayout()
        self.bronya_screen = None
        self.main_menu = None
        self.choice_screen = None
        self.judge_screen = None

    def build(self):
        """构建应用"""
        Window.clearcolor = [0.05, 0.05, 0.1, 1]

        self.container = BoxLayout()

        # 创建各个屏幕
        self.bronya_screen = BronyaQuestionScreen(self)
        self.main_menu = MainMenuScreen(self)
        self.choice_screen = ChoiceScreen(self)
        self.judge_screen = JudgeScreen(self)

        # 显示第一个屏幕（总是显示布洛妮娅问题）
        self.show_first_screen()

        return self.container

    def show_first_screen(self):
        """显示第一个屏幕"""
        # 总是显示布洛妮娅问题（如您所愿）
        self.show_bronya_question()

    def show_bronya_question(self):
        """显示布洛妮娅问题"""
        self.container.clear_widgets()
        self.container.add_widget(self.bronya_screen)

    def show_main_menu(self):
        """显示主菜单"""
        self.container.clear_widgets()
        if self.main_menu:
            self.main_menu.update_title()
            self.container.add_widget(self.main_menu)

    def show_choice_screen(self):
        """显示选择题屏幕"""
        self.container.clear_widgets()

        if not self.choice_questions:
            self.show_error_popup("题库为空", "选择题题库为空或加载失败，请检查chose.txt文件")
            return

        if not self.choice_screen:
            self.choice_screen = ChoiceScreen(self)

        self.choice_screen.start_quiz(self.choice_questions)
        self.container.add_widget(self.choice_screen)

    def show_judge_screen(self):
        """显示判断题屏幕"""
        self.container.clear_widgets()

        if not self.judge_questions:
            self.show_error_popup("题库为空", "判断题题库为空或加载失败，请检查right.txt文件")
            return

        if not self.judge_screen:
            self.judge_screen = JudgeScreen(self)

        self.judge_screen.start_quiz(self.judge_questions)
        self.container.add_widget(self.judge_screen)

    def load_questions(self):
        """加载题库"""
        # 加载选择题
        if os.path.exists("chose.txt"):
            try:
                with open("chose.txt", "r", encoding="utf-8") as f:
                    content = f.read().splitlines()

                    for line_num, line in enumerate(content, 1):
                        line = line.strip()

                        if not line or line.startswith("#"):
                            continue

                        try:
                            match = re.match(r'^(.+?)\s+(\d+)(?:\s+(.+))?$', line)
                            if not match:
                                continue

                            question = match.group(1).strip()
                            answer = match.group(2).strip()
                            options_str = match.group(3).strip() if match.group(3) else ""

                            options = []
                            if options_str:
                                temp_options = re.split(r'\s+', options_str)
                                options = [opt.strip() for opt in temp_options if opt.strip()]

                            if options:
                                self.choice_questions.append({
                                    "question": question,
                                    "answer": answer,
                                    "options": options,
                                    "is_multiple": len(answer) > 1
                                })

                        except Exception as e:
                            print(f"选择题第{line_num}行解析错误: {e}")
                            continue

                print(f"成功加载 {len(self.choice_questions)} 道选择题")

            except Exception as e:
                print(f"读取选择题题库出错: {e}")
                self.choice_questions = []
        else:
            print("警告: chose.txt 文件不存在")

        # 加载判断题
        if os.path.exists("right.txt"):
            try:
                with open("right.txt", "r", encoding="utf-8") as f:
                    content = f.read().splitlines()

                    for line_num, line in enumerate(content, 1):
                        line = line.strip()

                        if not line or line.startswith("#"):
                            continue

                        try:
                            pattern = r'^(.+?)\s+([01对错正确错误TtFf])\s*(.*)$'
                            match = re.match(pattern, line, re.IGNORECASE | re.UNICODE)

                            if match:
                                question = match.group(1).strip()
                                answer_str = match.group(2).strip().lower()
                                correction = match.group(3).strip() if match.group(3) else ""

                                if answer_str in ["1", "对", "正确", "true", "t"]:
                                    answer = "1"
                                elif answer_str in ["0", "错", "错误", "false", "f"]:
                                    answer = "0"
                                else:
                                    continue

                                options = ["正确", "错误"]

                                self.judge_questions.append({
                                    "question": question,
                                    "answer": answer,
                                    "options": options,
                                    "is_multiple": False,
                                    "correction": correction
                                })

                        except Exception as e:
                            print(f"判断题第{line_num}行解析错误: {e}")
                            continue

                print(f"成功加载 {len(self.judge_questions)} 道判断题")

            except Exception as e:
                print(f"读取判断题题库出错: {e}")
                self.judge_questions = []
        else:
            print("警告: right.txt 文件不存在")

    def show_error_popup(self, title, message):
        """显示错误弹窗"""
        content = BoxLayout(orientation='vertical', spacing=dp(10))
        content.add_widget(Label(
            text=message,
            font_size=sp(18),
            color=[1, 1, 1, 1]
        ))

        popup = Popup(
            title=title,
            title_color=[1, 1, 1, 1],
            content=content,
            size_hint=(0.7, 0.4),
            background_color=[0.91, 0.3, 0.24, 0.95]
        )

        close_btn = RoundedButton(
            text='确定',
            background_color=[0.8, 0.2, 0.2, 1]
        )
        close_btn.bind(on_press=lambda x: (popup.dismiss(), self.show_main_menu()))
        content.add_widget(close_btn)

        popup.open()


if __name__ == '__main__':
    try:
        # 设置窗口大小（调试用）
        Window.size = (360, 640)

        # 运行应用
        print("正在启动WAR GUIDE TALK应用...")
        app = WarGuideTalkApp()
        app.run()

    except SystemExit:
        # 正常退出
        pass
    except Exception as e:
        import traceback

        print("\n" + "=" * 50)
        print("应用程序启动失败！错误信息：")
        print("=" * 50)
        print(f"错误类型: {type(e).__name__}")
        print(f"错误信息: {str(e)}")
        print("\n详细错误追踪：")
        traceback.print_exc()
        print("=" * 50)

        # 等待用户查看错误信息
        input("\n按Enter键退出...")